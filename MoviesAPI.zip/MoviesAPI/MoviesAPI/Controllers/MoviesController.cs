﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MoviesAPI.Models;
using MoviesAPI.Repository;
using MoviesAPI.ViewModels;

namespace MoviesAPI.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class MoviesController : ControllerBase
	{
		/// <summary>
		///     An <see cref="IMoviesRepository" /> representing the movies repository
		/// </summary>
		private readonly IMoviesRepository _moviesRepository;

		/// <summary>
		///     Initializes the controller
		/// </summary>
		/// <param name="moviesRepository">
		///     An <see cref="IMoviesRepository" /> representing and instance of the movies repository
		/// </param>
		public MoviesController(IMoviesRepository moviesRepository)
		{
			_moviesRepository = moviesRepository;
		}

		/// <summary>
		/// Get all movies
		/// </summary>
		/// <returns>List of <see cref="Movie"/></returns>
		[HttpGet]
		public async Task<ActionResult<List<Movie>>> GetAllMoviesAsync()
		{
			List<Movie> result = await _moviesRepository.GetAllMoviesAsync();

			if (result == null) result = new List<Movie>();

			return Ok(result);
		}

		/// <summary>
		/// Get movie by id
		/// </summary>
		/// <returns>List of <see cref="Movie"/></returns>
		[HttpGet("{id}")]
		public async Task<ActionResult<Movie>> GetMovieByIdAsync(int id)
		{
			Movie result = await _moviesRepository.GetMovieByIdAsync(id);

			if (result == null) return BadRequest("Movie not found!");

			return Ok(result);
		}

		/// <summary>
		/// Get all movies for genre id
		/// </summary>
		/// <param name="genreId">A <see cref="MovieGenre"/> id</param>
		/// <returns>List of <see cref="Movie"/></returns>
		[Route("[action]")]
		[HttpGet()]
		public async Task<ActionResult<List<Movie>>> GetMoviesByGenreAsync(int genreId)
		{
			List<Movie> result = await _moviesRepository.GetMoviesByGenreAsync(genreId);

			if (result == null) result = new List<Movie>();

			return Ok(result);
		}

		/// <summary>
		/// Add a new movie
		/// </summary>
		/// <param name="movie">A <see cref="Movie"/> object</param>
		/// <returns>The added <see cref="Movie"/> with its new identity Id</returns>
		[HttpPost]
		public async Task<ActionResult<Movie>> AddMovieAsync(Movie movie)
		{
			var result = await _moviesRepository.AddMovieAsync(movie);

			if (result == 0) return BadRequest("Duplicate movie!");

			movie.Id = result;

			return Ok(movie);
		}

		/// <summary>
		/// Update a movie
		/// </summary>
		/// <param name="movie">A <see cref="Movie" object/></param>
		/// <returns>The updated <see cref="Movie" object/> </returns>
		[HttpPut]
		public async Task<ActionResult<Movie>> UpdateMovieAsync(Movie movie)
		{
			var result = await _moviesRepository.UpdateMovieAsync(movie);

			if (result == 0) return BadRequest("Duplicate movie!");

			return Ok(movie);
		}

		/// <summary>
		/// Delete a movie
		/// </summary>
		/// <param name="id">The Id of the <see cref="Movie"/></param>
		/// <returns>True id successful</returns>
		[HttpDelete("{id}")]
		public async Task<ActionResult<bool>> DeleteMovieAsync(int id)
		{
			var result = await _moviesRepository.DeleteMovieAsync(id);

			return Ok(result);
		}

		/// <summary>
		/// Get all movie genre
		/// </summary>
		/// <returns>List of <see cref="MovieGenre"/></returns>
		[Route("[action]")]
		[HttpGet]
		public async Task<ActionResult<List<MovieGenre>>> GetAllMovieGenreAsync()
		{
			List<MovieGenre> movieGenres = await _moviesRepository.GetAllMovieGenreAsync();

			if (movieGenres == null) return new List<MovieGenre>();

			return Ok(movieGenres);
		}

		/// <summary>
		/// Get ratings and movie count per rating
		/// </summary>
		/// <returns>List of <see cref="Movie"/></returns>
		[Route("[action]")]
		[HttpGet]
		public async Task<ActionResult<List<RatingCount>>> GetRatingsCountAsync()
		{
			List<RatingCount> result = await _moviesRepository.GetRatingsCountAsync();

			if (result == null) result = new List<RatingCount>();

			return Ok(result);
		}

		[Route("[action]")]
		[HttpGet]
		public async Task<ActionResult<string>> GetMovieGenreReportAsync()
		{
			string result = await _moviesRepository.GetMovieGenreReportAsync();

			return Ok(result);
		}
	}
}
