﻿using Microsoft.Data.SqlClient;
using MoviesAPI.Models;
using Dapper;
using System.Text;
using MoviesAPI.ViewModels;

namespace MoviesAPI.Repository
{
	public class MoviesRepository : IMoviesRepository
	{
		private readonly MoviesContext ctx;

		public MoviesRepository() 
		{ 
			ctx = new MoviesContext();
		}

		/// <summary>
		/// Get all movies
		/// </summary>
		/// <returns>A list of <see cref="Movie"/></returns>
		public async Task<List<Movie>> GetAllMoviesAsync()
		{
			var sql = "SELECT * FROM Movies";
			var movies = new List<Movie>();
			try
			{
				using (var con = new SqlConnection(ctx.ConnString))
				{
					var result = await con.QueryAsync<Movie>(sql);
					movies = result.ToList();
				}
			}
			catch {	return new List<Movie>(); }

			return movies;
		}

		public async Task<Movie> GetMovieByIdAsync(int id)
		{
			var sql = $"SELECT * FROM Movies WHERE Id = {id}";
			var movie = new Movie();
			try
			{
				using (var con = new SqlConnection(ctx.ConnString))
				{
					var result = await con.QueryAsync<Movie>(sql);
					movie = result.FirstOrDefault();
				}
			}
			catch { return new Movie(); }

			return movie;
		}

		/// <summary>
		/// Get all movies of a specified genre
		/// </summary>
		/// <param name="genreId">The id of the movie genre</param>
		/// <returns>A list of <see cref="Movie"/></returns>
		public async Task<List<Movie>> GetMoviesByGenreAsync(int genreId)
		{
			var sql = $"SELECT * FROM Movies WHERE MovieGenreId = {genreId}";
			var movies = new List<Movie>();
			
			try
			{
				using (var con = new SqlConnection(ctx.ConnString))
				{
					var result = await con.QueryAsync<Movie>(sql);
					movies = result.ToList();
				}
			}
			catch {	return new List<Movie>(); }

			return movies;
		}

		/// <summary>
		/// Add a new movie if is doesn't exist
		/// </summary>
		/// <param name="movie">A <see cref="Movie"/> object</param>
		/// <returns>The new Id. If Id = 0 then the movie was not added</returns>
		public async Task<int> AddMovieAsync(Movie movie)
		{
			// Validate movie object
			if (IsValidMovie(movie) == false) return 0;

			// Check if movie already exists
			var doesExist = await DoesMovieExistAsync(0, movie.Title);
			if (doesExist) { return 0; }

			int id = 0;
			var sql = $"INSERT INTO Movies (Title, MovieGenreId, Rating) OUTPUT INSERTED.Id VALUES ('{movie.Title}', {movie.MovieGenreId}, {movie.Rating})";
			
			try
			{
				using (var con = new SqlConnection(ctx.ConnString))
				{
					id = await con.QuerySingleAsync<int>(sql);
				}
			}
			catch { return 0; }

			return id;
		}

		/// <summary>
		/// Update an existing movie
		/// </summary>
		/// <param name="movie">A <see cref="Movie"/> object</param>
		/// <returns>The Id of the updated movie, or 0 if update failed</returns>
		public async Task<int> UpdateMovieAsync(Movie movie)
		{
			// Validate movie object
			if (IsValidMovie(movie) == false) return 0;

			// Check if movie already exists
			var doesExist = await DoesMovieExistAsync(movie.Id, movie.Title);
			if (doesExist) { return 0; }

			int id = 0;
			var sql = $"UPDATE Movies SET Title = '{movie.Title}', MovieGenreId = {movie.MovieGenreId}, Rating = {movie.Rating} WHERE Id = {movie.Id}";
			
			try
			{
				using (var con = new SqlConnection(ctx.ConnString))
				{
					var rowsAffected = await con.ExecuteAsync(sql);
					if (rowsAffected != 0) id = movie.Id;
				}
			}
			catch { return 0; }

			return id;
		}

		/// <summary>
		/// Delete a movie
		/// </summary>
		/// <param name="id">The Id of the <see cref="Movie"/> object</param>
		/// <returns>True if successful</returns>
		public async Task<bool> DeleteMovieAsync(int id)
		{
			bool result = false;
			var sql = $"DELETE FROM Movies WHERE ID = {id}";

			try
			{
				using (var con = new SqlConnection(ctx.ConnString))
				{
					var rowsAffected = await con.ExecuteAsync(sql);
					if (rowsAffected > 0) result = true;
				}
			}
			catch { return false; }

			return result;
		}

		/// <summary>
		/// Get all movie genres
		/// </summary>
		/// <returns>List of <see cref="MovieGenre"/></returns>
		public async Task<List<MovieGenre>> GetAllMovieGenreAsync()
		{
			var sql = "SELECT * FROM MovieGenres";
			var movieGenre = new List<MovieGenre>();
			try
			{
				using (var con = new SqlConnection(ctx.ConnString))
				{
					var result = await con.QueryAsync<MovieGenre>(sql);
					movieGenre = result.ToList();
				}
			}
			catch { return new List<MovieGenre>(); }

			return movieGenre;
		}

		/// <summary>
		/// Get ratings and the total movie count for each rating
		/// </summary>
		/// <returns>A list of <see cref="RatingCount"/></returns>
		public async Task<List<RatingCount>> GetRatingsCountAsync()
		{
			var sql = "SELECT Rating, COUNT(Title) AS MovieCount FROM Movies GROUP BY Rating";
			var ratings = new List<RatingCount>();
			try
			{
				using (var con = new SqlConnection(ctx.ConnString))
				{
					var result = await con.QueryAsync<RatingCount>(sql);
					ratings = result.ToList();
				}
			}
			catch { return new List<RatingCount>(); }

			return ratings;
		}

		public async Task<string> GetMovieGenreReportAsync()
		{
			var sql = "SELECT Movies.Id, Movies.Title, Movies.MovieGenreId, MovieGenres.GenreName, Movies.Rating " +
				"FROM Movies LEFT JOIN MovieGenres ON Movies.MovieGenreId = MovieGenres.Id ORDER BY Movies.MovieGenreId, Movies.Title";
			var data = new List<MovieGenreReport>();
			var sb = new StringBuilder();
			string report = string.Empty;
			int currentGenre = 0;
			bool isStart = true;
			string json = string.Empty;
			try
			{
				using (var con = new SqlConnection(ctx.ConnString))
				{
					var result = await con.QueryAsync<MovieGenreReport>(sql);
					data = result.ToList();
				}
				if (data.Count > 0)
				{

					foreach(var movie in data)
					{
						if (currentGenre != movie.MovieGenreId)
						{
							if (isStart is not true)
							{
								sb.AppendLine("</tbody></table>");
							}
							else isStart = false;
							sb.AppendLine("<br /><h3>" + movie.genreName?.ToUpper() + "</h3>");
							sb.AppendLine("<table><thead><th>&nbsp;&nbsp;Id&nbsp;&nbsp;</th><th>&nbsp;&nbsp;Title&nbsp;&nbsp;</th><th>&nbsp;&nbsp;Rating&nbsp;&nbsp;</th></thead><tbody>");
							currentGenre = movie.MovieGenreId;
						}
						sb.AppendLine($"<tr><td>&nbsp;&nbsp;{movie.Id}&nbsp;&nbsp;</td><td>&nbsp;&nbsp;{movie.Title}&nbsp;&nbsp;</td><td>&nbsp;&nbsp;{movie.Rating}&nbsp;&nbsp;</td></tr>");
					}
					sb.AppendLine("</tbody></table>");
				}
				sb.AppendLine("<br /><p>--- End of Report ---</p>");
				report = sb.ToString();
			}
			catch { return "No movies found!"; }

			return report;
		}		

		#region Helpers

		/// <summary>
		/// Validate content of movie object
		/// </summary>
		/// <param name="movie">A <see cref="Movie"/> object</param>
		/// <returns>True is valid, else false</returns>
		private bool IsValidMovie(Movie movie)
		{
			if (movie.Title == null) return false;
			if (movie.MovieGenreId == 0) return false;
			if (movie.Rating == 0) return false;

			return true;
		}

		/// <summary>
		/// Check is movie already exists
		/// </summary>
		/// <param name="title">The title of the movie</param>
		/// <returns>True if already exists, otherwise false</returns>
		private async Task<bool> DoesMovieExistAsync(int id, string title)
		{
			title = title.ToUpper();
			bool doesExist = true;
			var sql = $"SELECT * FROM Movies WHERE UPPER(Title) = '{title}' AND Id != {id}"; // avoid checking itself

			try
			{
				using (var con = new SqlConnection(ctx.ConnString))
				{
					var result = await con.QueryAsync<Movie>(sql);
					var movies = result.ToList();
					if (movies.Count == 0) doesExist = false;
				}
			}
			catch { return true; }

			return doesExist;
		}



		#endregion

	}
}
