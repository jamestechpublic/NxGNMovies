﻿using MoviesAPI.Models;
using MoviesAPI.ViewModels;

namespace MoviesAPI.Repository
{
	public interface IMoviesRepository
	{
		Task<List<Movie>> GetAllMoviesAsync();
		Task<Movie> GetMovieByIdAsync(int id);
		Task<List<Movie>> GetMoviesByGenreAsync(int genre);
		Task<int> AddMovieAsync(Movie movie);
		Task<int> UpdateMovieAsync(Movie movie);
		Task<bool> DeleteMovieAsync(int id);
		Task<List<MovieGenre>> GetAllMovieGenreAsync();
		Task<List<RatingCount>> GetRatingsCountAsync();
		Task<string> GetMovieGenreReportAsync();
	}
}
