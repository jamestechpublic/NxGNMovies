﻿using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace MoviesAPI.Repository
{
	public class MoviesContext
	{
		public string? ConnString { get; }

		/// <summary>
		/// Initialize class and retrieve the connection string from appsettings.json
		/// </summary>
		public MoviesContext()
		{
			var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
			IConfiguration _configuration = builder.Build();
			ConnString = _configuration.GetConnectionString("MoviesDB");
		}

	}
}
