﻿namespace MoviesAPI.Models
{
	public class Movie
	{
		public int Id { get; set; }
		public string? Title { get; set; } = string.Empty;
		public int MovieGenreId { get; set; }
		public int Rating { get; set; }
	}
}
