﻿namespace MoviesAPI.Models
{
	public class MovieGenre
	{
		public int Id { get; set; }
		public string? GenreName { get; set; } = string.Empty;
	}
}
