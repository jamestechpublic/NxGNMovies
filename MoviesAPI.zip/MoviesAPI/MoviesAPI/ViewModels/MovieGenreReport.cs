﻿namespace MoviesAPI.ViewModels
{
	public class MovieGenreReport
	{
		public int Id { get; set; }
		public string? Title { get; set; } = string.Empty;
		public int MovieGenreId { get; set; }
		public string? genreName { get; set; } = string.Empty;
		public int Rating { get; set; }
	}
}
