﻿namespace MoviesAPI.ViewModels
{
	public class RatingCount
	{
		public int Rating { get; set; }
		public int MovieCount { get; set; }
	}
}
