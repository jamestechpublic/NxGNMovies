export class MovieRating{
    id?: number;
    ratingName = "";
}