export class MovieGenre{
    id?: number;
    genreName = "";
}