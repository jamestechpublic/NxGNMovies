export class RatingCount {
    rating?: number;
    movieCount?: number;
}