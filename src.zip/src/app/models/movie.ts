export class Movie {
    id = 0;
    title = "";
    movieGenreId = 1;
    rating = 1;
}