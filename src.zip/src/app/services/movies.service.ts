import { Injectable } from '@angular/core';
import { Movie } from '../models/movie';
import { MovieGenre } from '../models/movieGenre';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { MovieRating } from '../models/movieRating';
import { RatingCount } from '../models/ratingCount';

@Injectable({
  providedIn: 'root'
})
export class MoviesService {
  private movieUrl = "https://localhost:7196/api/Movies";
  private genreUrl = "https://localhost:7196/api/Movies/GetAllMovieGenre";
  private movieByGenreUrl = "https://localhost:7196/api/Movies/GetMoviesByGenre";
  private ratingCountUrl = "https://localhost:7196/api/Movies/GetRatingsCount";
  private movieGenreReportUrl = "https://localhost:7196/api/Movies/GetMovieGenreReport";


  constructor(private _http: HttpClient) { }

  public getAllMovies() : Observable<Movie[]> {
    return this._http.get<Movie[]>(this.movieUrl);
  }

  public getMoviesByGenre(genreId: number) : Observable<Movie[]> {
    return this._http.get<Movie[]>(this.movieByGenreUrl + "?genreId=" + genreId);
  }

  public getMovieById(id: number) : Observable<Movie> {
    return this._http.get<Movie>(this.movieUrl + "/" + id);
  }

  public getAllMovieGenre(): Observable<MovieGenre[]> {
    return this._http.get<MovieGenre[]>(this.genreUrl);
  }

  public getRatings() : MovieRating[] {
    return [
      { id: 1, ratingName: "1" }, 
      { id: 2, ratingName: "2" },
      { id: 3, ratingName: "3" },
      { id: 4, ratingName: "4" },
      { id: 5, ratingName: "5" }
    ];
  }

  public updateMovie(movie: Movie): Observable<any> {
    return this._http.put(this.movieUrl, movie);
  }

  public addMovie(movie: Movie): Observable<any> {
    return this._http.post(this.movieUrl, movie);
  }

  public deleteMovie(id: number): Observable<any> {
      return this._http.delete(this.movieUrl + "/" + id);
  }

  public getRatingsCount() : Observable<RatingCount[]> {
    return this._http.get<RatingCount[]>(this.ratingCountUrl);
  }

  public getMovieGenreReport() : Observable<any> {
    return this._http.get(this.movieGenreReportUrl, {responseType: 'text'});
  }

}
