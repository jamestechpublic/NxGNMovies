import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MovieAddEditComponent } from './components/movie-add-edit/movie-add-edit.component';
import { MovieListComponent } from './components/movie-list/movie-list.component';
import { RatingsReportComponent } from './components/ratings-report/ratings-report.component';
import { MovieGenreReportComponent } from './components/movie-genre-report/movie-genre-report.component';

const routes: Routes = [
  {
    path: '',
    component: MovieListComponent
  },
  {
    path: "movieAddEdit/:id",
    component: MovieAddEditComponent
  },
  {
    path: "ratingsReport",
    component: RatingsReportComponent
  },
  { 
    path: "movieGenreReport",
    component: MovieGenreReportComponent
  },
  {
    path: "**",
    component: MovieListComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
