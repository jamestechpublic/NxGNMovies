import { Component, ViewChild } from '@angular/core';
import { Movie } from 'src/app/models/movie';
import { MoviesService } from 'src/app/services/movies.service';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { MovieGenre } from 'src/app/models/movieGenre';
import { CoreService } from 'src/app/core/core.service';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.css']
})
export class MovieListComponent {
  movies: Movie[] = [];
  movieToEdit? : Movie;
  genres: MovieGenre[] = [];
  movieForm: FormGroup;
  selectedGenre: number;

  displayedColumns: string[] = ['id', 'title', 'movieGenreId', 'rating', 'action'];
  dataSource!: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;

  constructor(private _service : MoviesService, private _core: CoreService, private _fb: FormBuilder) {
    this.movieForm = this._fb.group({
      filterText: "",
      genreId: 0 
    });
    this.selectedGenre = 0;
   }

  ngOnInit() : void {
    this.getGenres();
    this.getMoviesList();
  }

  getGenres() {
    this._service.getAllMovieGenre().subscribe({
      next: (val: MovieGenre[]) => {
        this.genres = val;
        let allGenre = new MovieGenre();
        allGenre.id = 0;
        allGenre.genreName = "All"
        this.genres = [allGenre].concat(this.genres);
      },
      error: console.log
    });
  }

  getGenreName(id: number) : string {
    return this.genres[id].genreName;
  }

  getMoviesList() {
    this._service.getAllMovies().subscribe({
      next: (res) => {
        this.dataSource = new MatTableDataSource(res);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      },
      error: console.log
    });
  }

  filterByGenre(genreId: number | undefined) {
    this.movieForm.controls['filterText'].setValue("");
    this.selectedGenre = genreId ??= 0;
    if (this.selectedGenre == 0) this.getMoviesList();
    else this.getMoviesListByGenre(this.selectedGenre);
  }

  getMoviesListByGenre(genreId: number) {
    this._service.getMoviesByGenre(genreId).subscribe({
      next: (res) => {
        this.dataSource = new MatTableDataSource(res);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      },
      error: console.log
    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  deleteMovie(id: number, title: string) {
    if (confirm(`Delete movie: "${title}"`)) {
      this._service.deleteMovie(id).subscribe({
        next: (res) => {
          this._core.openSnackBar(`Movie "${title}" deleted!`, 'ok');
          this.selectedGenre = 0;
          this.movieForm.controls['genreId'].setValue(this.selectedGenre);
          this.getMoviesList();
        },
        error: console.log
      });
    }
  }
}
