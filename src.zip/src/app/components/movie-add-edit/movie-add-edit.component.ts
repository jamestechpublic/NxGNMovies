import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Movie } from 'src/app/models/movie';
import { MovieGenre } from 'src/app/models/movieGenre';
import { MoviesService } from 'src/app/services/movies.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { MovieRating } from 'src/app/models/movieRating';
import { CoreService } from 'src/app/core/core.service';

@Component({
  selector: 'app-movie-add-edit',
  templateUrl: './movie-add-edit.component.html',
  styleUrls: ['./movie-add-edit.component.css']
})
export class MovieAddEditComponent implements OnInit {
  title = "Add New Movie";
  movieId: number;
  movieToEdit = new Movie();
  saveText = "Save";
  movieForm: FormGroup;
  genres: MovieGenre[] = [];
  ratings: MovieRating[] = [];
  selectedRating = 0;

  constructor(private _activatedRoute: ActivatedRoute, private _router: Router, private _fb: FormBuilder,
              private _service: MoviesService, private _core: CoreService) {
    this.movieForm = this._fb.group({
      id: 0, 
      title: ["", Validators.required],
      movieGenreId: [0, Validators.min(1)],
      rating: [0, Validators.min(1)]
    });

    this.movieId = this._activatedRoute.snapshot.params["id"];
  }

  ngOnInit() {
    this.getGenres();
    this.getRatings();
    if (this.movieId != 0) {
      this.getMovie(this.movieId);
      this.title = "Edit > " + this.movieToEdit.title;
      this.saveText = "Update";
    }
  }

  get f(): { [key: string]: AbstractControl } {
    return this.movieForm.controls;
  }

  getGenres() {
    this._service.getAllMovieGenre().subscribe({
      next: (val: MovieGenre[]) => {
        this.genres = val;
      },
      error: console.log
    });
  }

  getRatings() {
    this.ratings = this._service.getRatings();
  }

  getMovie(id: number) {
    this._service.getMovieById(this.movieId).subscribe({
      next: (val: Movie) => {
        this.movieToEdit = val;
        this.movieForm.setValue({ 
          id: this.movieToEdit.id,
          title: this.movieToEdit.title,
          movieGenreId: this.movieToEdit.movieGenreId,
          rating: this.movieToEdit.rating
        });
        this.title = "Edit > " + this.movieToEdit.title;
      },
      error: console.log
    });
  }

  onFormSubmit() {
    if (this.movieForm.valid) {
      if (this.movieId == 0) {
        this.movieForm.value["rating"] = Number(this.movieForm.value["rating"]);
        this._service.addMovie(this.movieForm.value).subscribe({
          next: (val: any) => {
            this._core.openSnackBar('Movie added successfully', 'ok');
            this._router.navigate([""]);
          },
          error: console.log
        });
      }
      else {
        this.movieForm.value["rating"] = Number(this.movieForm.value["rating"]);
        this.movieForm.value["id"] = this.movieId;
        this._service.updateMovie(this.movieForm.value).subscribe({
          next: (val: any) => {
            this._core.openSnackBar('Movie updated successfully', 'ok');
            this._router.navigate([""]);
          },
          error: console.log
        });
      }
    }
  }
}
