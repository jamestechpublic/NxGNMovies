import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { RatingCount } from 'src/app/models/ratingCount';
import { MoviesService } from 'src/app/services/movies.service';

@Component({
  selector: 'app-ratings-report',
  templateUrl: './ratings-report.component.html',
  styleUrls: ['./ratings-report.component.css']
})
export class RatingsReportComponent implements OnInit {
  movieForm: FormGroup;

  displayedColumns: string[] = ['rating', 'movieCount'];
  dataSource!: MatTableDataSource<any>;
  @ViewChild(MatSort) sort!: MatSort;

  constructor (private _service: MoviesService, private _fb: FormBuilder) {
    this.movieForm = this._fb.group({ });
  }

  ngOnInit() {
    this.getRatingCount();
  }

  getRatingCount() {
    this._service.getRatingsCount().subscribe({
      next: (res) => {
        this.dataSource = new MatTableDataSource(res);
        this.dataSource.sort = this.sort;
      },
      error: console.log
    });
  }

  onExportClick() : void {
    this._service.getRatingsCount().subscribe({
      next: (res) => {
        //let jsonObject = JSON.stringify(res);
        let result = this.convertToCSV(res)
        this.downloadFile(result);
      },
      error: console.log
    });
  }

  downloadFile(data: any) : void {
    let filename = "ratings.csv";
    let file = new Blob([data], {type: "text/plain"});

    // create temporary link to download file...
    let link = document.createElement("a");
    link.href = URL.createObjectURL(file);
    link.download = filename;
    link.click();
    link.remove();
  }

  convertToCSV(data: any) : string {
    let array = typeof data != "object" ? JSON.parse(data) : data;
    let result = "Rating;Movie Count" + "\r\n"; //heading

    // Manually convert data to CSV - Note: Excel uses a semi-colon (;)
    for (var i = 0; i < array.length; i++) {
        let line = "";
        for (var index in array[i]) {
            if (line != "") line += ";"
            line += array[i][index];
        }
        result += line + "\r\n";
    }

    return result;
  }
}