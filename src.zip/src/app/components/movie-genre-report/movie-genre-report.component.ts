import { Component } from '@angular/core';
import { MoviesService } from 'src/app/services/movies.service';

@Component({
  selector: 'app-movie-genre-report',
  templateUrl: './movie-genre-report.component.html',
  styleUrls: ['./movie-genre-report.component.css']
})
export class MovieGenreReportComponent {
  report = "No movies found!";

  constructor(private _service: MoviesService) {
    this.getMovieGenreReport();
  }

  getMovieGenreReport() {
    this._service.getMovieGenreReport().subscribe({
      next: (res) => {
        console.log(res);
        this.report = res;
      },
      error: console.log
    });
  }

}
